import UIKit
import UIKit

//comentario
/*comentario
 varias
 lineas*/
let cosa1 : Int = 18
let cosa2 : Float = 11.34
let cosa3 : Bool = false
let cosa4 : Double = 27.53435354
let cosa5 : String = "👂"
var greeting = "Hello, playground"

let 🍎 : Int = 10
let 🍌 : Int = 4
let 🥥 : Int = 2

let suma = 🍎+🍎+🍎
let suma1 = 🍎+🍌+🍌
let resta = 🍌-🥥
let suma2 = 🥥+🍎+🍌

let cuenta : Int = 318229261
let nombre = "Andrea"
let correo = "318229261@pcpuma.acatlan.unam.mx"
print ("Soy" ,nombre, "mi número de cuenta es:" ,cuenta, "y mi correo institucional es:" ,correo)

//Jerarquia de operadores
var x : Int

x = 5 + 7 * 5 + 3
print (x)

x = 5 + 7 * (5 + 3)
print (x)

x = (5 + 7) * 5 + 3
print (x)

x = 5 + (7 * 5) + 3
print (x)

x = (12 / 2) / 3 + 3 * 4 - 6
print (x)


