import UIKit
var i = 0
for i in 1...10{
    print(i)
}
i = 0
for i in stride(from: 1, to: 20, by: +2){
    print(i)
}
i = 0
var arreglo : [Int]=[]
for i in stride(from: 2, to: 11, by: +2){
    arreglo.append(i)
}
var contador = 10
while contador > 0{
    print(contador)
contador += -1
}
func nombre(){
    print("cristian")
}
nombre()
func saludo (nombres : String,  apellido: String){
    print("hola soy \(nombres) \(apellido)  ")
}
var nombres : String = "cristian"
var apellido: String = "mendoza"
saludo(nombres : "cristian", apellido :"mendoza" )
func area(h:Double , b: Double)-> Double{
    let altura:Double = h
    let base : Double = b
    let area : Double = (altura * base)/2
    return area
}
let areas = area(h:3.4, b:6.8)
